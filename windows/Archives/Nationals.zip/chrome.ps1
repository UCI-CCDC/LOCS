[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$ProgressPreference = 'SilentlyContinue'

netsh a f a r n=WEB_OUT dir=out a=allow prot=TCP remoteport="80,443"

iwr "https://dl.google.com/chrome/install/latest/chrome_installer.exe" -o "C:\Users\Administrator\Documents\ChromeSetup.exe" -UseBasicParsing

netsh a f del r n=WEB_OUT
