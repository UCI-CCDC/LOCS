gpupdate /force
netsh advfirewall set allprofiles state on